# TODO

- Change settings to use color picker type, not string
- Change algorithm to sum up past X seconds instead of just accumulating infinitely
