data:extend{
    {
        type = "bool-setting",
        name = "aa-magnetic-selection",
        setting_type = "runtime-global",
        default_value = true,
        order = "a"
    },
    {
        type = "bool-setting",
        name = "aa-resnap-zone-on-change",
        setting_type = "runtime-global",
        default_value = true,
        order = "b"
    },
    {
        type = "bool-setting",
        name = "aa-reset-data-on-change",
        setting_type = "runtime-global",
        default_value = false,
        order = "c"
    },
    {
        type = "bool-setting",
        name = "aa-exclude-inserters",
        setting_type = "runtime-global",
        default_value = false,
        order = "d"
    }
}